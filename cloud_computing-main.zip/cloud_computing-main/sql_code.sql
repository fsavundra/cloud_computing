/* Command to create the SQL table */ 
CREATE TABLE stock_data (
pk_stock_id INT(6),
stock_name VARCHAR(30) NOT NULL,
stock_symbol VARCHAR(30) NOT NULL
)